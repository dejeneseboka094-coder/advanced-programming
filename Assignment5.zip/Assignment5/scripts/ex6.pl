#!/usr/bin/perl
use strict;
use warnings;

my $seq = "ATCGAATTCGGGGAATTCATC";
my $pattern = "GAATTC";

while ($seq =~ /(?=$pattern)/g) {

    my $pos = pos($seq) + 1;

    print "EcoRI found at position $pos\n";

    pos($seq)++;
}
