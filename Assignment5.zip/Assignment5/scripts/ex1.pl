#!/usr/bin/perl
use strict;
use warnings;

my $gene = "EDN3";
my $chromosome = "chr13";
my $length = 2156;

print "Gene: $gene\n";
print "Chromosome: $chromosome\n";
print "Length: $length\n";
