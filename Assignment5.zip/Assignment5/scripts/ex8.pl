#!/usr/bin/perl
use strict;
use warnings;
use Bio::SeqIO;

my $seqio = Bio::SeqIO->new(
    -file   => "../data/genes.fasta",
    -format => "fasta"
);

while (my $seq = $seqio->next_seq) {

    print "ID: ", $seq->display_id, "\n";
    print "Length: ", $seq->length, "\n";
    print "First 10 bp: ", substr($seq->seq, 0, 10), "\n\n";
}
