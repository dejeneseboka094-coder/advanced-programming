#!/usr/bin/perl
use strict;
use warnings;

my $seq = "ATGCCGAAT";

# Step 1: reverse sequence
my $rev = reverse($seq);

# Step 2: complement
$rev =~ tr/ATGC/TACG/;

print "Reverse Complement: $rev\n";

