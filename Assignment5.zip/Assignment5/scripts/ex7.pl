#!/usr/bin/perl
use strict;
use warnings;

my $file = "../data/genes.fasta";

open(my $fh, "<", $file) or die "Cannot open FASTA file\n";

my ($id, $seq) = ("", "");

print "ID\tLength\n";

while (<$fh>) {

    chomp;

    if (/^>(\S+)/) {

        if ($id ne "") {
            print "$id\t", length($seq), "\n";
        }

        $id = $1;
        $seq = "";
    }
    else {
        $seq .= $_;
    }
}

print "$id\t", length($seq), "\n";

close($fh);
