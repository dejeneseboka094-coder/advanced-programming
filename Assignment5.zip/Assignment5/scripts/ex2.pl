#!/usr/bin/perl
use strict;
use warnings;

my @genes = ("EDN3", "PDE5A", "DNAH7", "IKBKG");

foreach my $gene (@genes) {
    print "$gene\n";
}
