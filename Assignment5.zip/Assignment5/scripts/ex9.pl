#!/usr/bin/perl
use strict;
use warnings;
use Bio::DB::GenBank;

my $db = Bio::DB::GenBank->new();

my $seq = $db->get_Seq_by_acc("NM_174738");

print "Accession: ", $seq->accession_number, "\n";
print "Description: ", $seq->desc, "\n";
print "Length: ", $seq->length, "\n";
