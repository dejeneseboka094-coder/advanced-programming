#!/usr/bin/perl
use strict;
use warnings;
use Bio::SearchIO;

my $blast = Bio::SearchIO->new(
    -file   => "data/blast_output.txt",
    -format => "blast"
);

print "Hit\tE-value\tIdentity\n";

while (my $result = $blast->next_result) {

    while (my $hit = $result->next_hit) {

        while (my $hsp = $hit->next_hsp) {

            printf "%s\t%s\t%.2f\n",
                $hit->name,
                $hsp->evalue,
                $hsp->percent_identity;

            last;
        }
    }
}
