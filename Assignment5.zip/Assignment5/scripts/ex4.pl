#!/usr/bin/perl
use strict;
use warnings;

my $seq = "ATGCGCGATATCGCGAT";

# 1. Length
my $length = length($seq);

# 2. Count G and C
my $g_count = ($seq =~ tr/G/G/);
my $c_count = ($seq =~ tr/C/C/);

# 3. GC count
my $gc_count = $g_count + $c_count;

# 4. GC percentage
my $gc_percent = ($gc_count / $length) * 100;

# Output
printf "Length: %d\n", $length;
printf "GC Count: %d\n", $gc_count;
printf "GC%%: %.2f\n", $gc_percent;
